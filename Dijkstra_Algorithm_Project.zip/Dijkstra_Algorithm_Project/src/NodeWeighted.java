import java.util.*;
public class NodeWeighted {
    int n;
    String name;
    private boolean visited;
    LinkedList<EdgeWeighted> edges;

    public NodeWeighted (int n, String name) {
        this.n = n;
        this.name = name;
        visited = false;
        edges = new LinkedList<>();
    }
    public boolean isVisited(){
        return visited;
    }
    public void visit() {
        visited = true;
    }
    public void unvisit(){
        visited = false;
    }
}
