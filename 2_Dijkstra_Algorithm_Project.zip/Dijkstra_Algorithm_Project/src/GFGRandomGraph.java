import java.util.*;
import java.io.*;

public class GFGRandomGraph {

    public int vertices;
    public int edges;

    int MAX_LIMIT;

    Random random = new Random();
    public List<List<Integer>> adjacencyList;

    public GFGRandomGraph(int n) {
        this.vertices = random.nextInt(MAX_LIMIT) + 1;
        this.edges = random.nextInt(computeMaxEdges(vertices)) + 1;
        this.MAX_LIMIT = n;

        adjacencyList = new ArrayList<>(vertices);
        for (int i = 0; i < vertices; i++)
            adjacencyList.add(new ArrayList<>());

        for (int i = 0; i < edges; i++) {
            int v = random.nextInt(vertices);
            int w = random.nextInt(vertices);

            if ((v == w) || adjacencyList.get(v).contains(w)) {
                // Reduce the value of i
                // so that again v and w can be chosen
                // for the same edge count
                i = i - 1;
                continue;
            }

            addEdge(v, w);
        }
    }

    int computeMaxEdges(int numOfVertices) {
        // As it is an undirected graph
        // So, for a given number of vertices V
        // there can be at-most V*(V-1)/2 number of edges
        return numOfVertices * ((numOfVertices - 1) / 2);
    }

    // Method to add edges between given vertices
    void addEdge(int v, int w) {
        // Note: it is an Undirected graph

        // Add w to v's adjacency list
        adjacencyList.get(v).add(w);

        // Add v to w's adjacency list
        // if v is not equal to w
        if (v != w)
            adjacencyList.get(w).add(v);
        // The above condition is important
        // If you don't apply the condition then
        // two self-loops will be created if
        // v and w are equal
    }
}