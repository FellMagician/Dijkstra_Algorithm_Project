import java.util.*;
public class Verticy {
    String name;
    private boolean visited;
    LinkedList<EdgeWeighted> edges;

    public Verticy (String name) {
        this.name = name;
        visited = false;
        edges = new LinkedList<>();
    }
    public boolean isVisited(){
        return visited;
    }
    public void visit() {
        visited = true;
    }
    public void unvisit(){
        visited = false;
    }
}
