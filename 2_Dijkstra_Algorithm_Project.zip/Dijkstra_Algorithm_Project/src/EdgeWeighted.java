import java.util.*;
public class EdgeWeighted implements Comparable<EdgeWeighted> {
    Verticy source;
    Verticy destination;
    double weight;

   public EdgeWeighted (Verticy s, Verticy d, double w)
    {
        source = s;
        destination = d;
        weight = w;
    }
    public String toString()
    {
        return String.format("(%s -> %s, %f)", source.name, destination.name, weight);
    }
    public int compareTo(EdgeWeighted otherEdge)
    {
        if (this.weight > otherEdge.weight)
            return 1;
        return -1;
    }
}
