import java.util.*;
public class NodeWeighted {
    String name;
    private boolean visited;
    LinkedList<EdgeWeighted> edges;

    public NodeWeighted (String name) {
        this.name = name;
        visited = false;
        edges = new LinkedList<>();
    }
    public boolean isVisited(){
        return visited;
    }
    public void visit() {
        visited = true;
    }
    public void unvisit(){
        visited = false;
    }
}
